<h3>OBJECT ORIENTED PROGRAMMING LAB (IN JAVA) SET2</h3>
<br>

**1.** Java class having overloaded methods to calculate area of rectangle
and circle.<br>

**2.** Define a class Queue for representing a queue data structure. The class must define a default constructor, a parameterized constructor and functions for enqueue, dequeue and display operations. Write a Java program to implement this.<br>

**3.** Program to print the area and perimeter of a triangle having sides of 3, 4 and 5 units by creating a class named 'Triangle' without any parameter in its constructor.<br>

**4.** Program to print the area of a rectangle by creating a class named 'Area' taking the values of its length and breadth as parameters of its constructor and having a method named 'returnArea' which returns the area of the rectangle. Length and breadth of rectangle are entered through keyboard.<br>

**5.** Class with a method that prints "This is parent class" and its subclass with another method that prints "This is child class". Now, create an object for each of the class and call<br>
  - method of parent class by object of parent class<br>
  - method of child class by object of child class<br>
  - method of parent class by object of child class<br>



