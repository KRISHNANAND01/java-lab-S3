<h3>OBJECT ORIENTED PROGRAMMING LAB (IN JAVA) SET1</h3>

1.print “hello world”<br/>

2.add two numbers<br/>

3.check given no is odd or even<br/>

4.check given no is prime or not<br/>

5.find the sum of first “n” natural numbers<br/>

6.find the factor of a given number<br/>

7.print Fibonacci series<br/>

8.factorial of first n numbers<br/>

9.check given no is palindrome or not<br/>

10.amstrong or not
